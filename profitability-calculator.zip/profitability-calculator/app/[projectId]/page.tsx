import React from "react";

import ProfitabilityCalculator from "@/components/profitability-calculator";

const ProjectPage = () => {
  return <ProfitabilityCalculator />;
};

export default ProjectPage;
