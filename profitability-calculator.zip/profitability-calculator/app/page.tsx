"use client";

import NewProjectDialog from "@/components/new-project-dialog";
import ProjectSelect from "@/components/project-select";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

import { PlusCircle } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [isNewProjectDialogOpen, setIsNewProjectDialogOpen] = useState(false);

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <img
            src="/placeholder.svg?height=50&width=200"
            alt="Logo"
            className="h-12"
          />
          <ProjectSelect />
        </div>

        <h1 className="text-3xl font-bold">Profitability Calculator</h1>
      </div>

      <div className="flex items-center justify-center h-full">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <h2 className="text-2xl font-bold mb-4">
              Welcome to Profitability Calculator
            </h2>
            <p className="mb-6 text-gray-600">
              You don&apos;t have any projects yet. Let&apos;s create your first
              project!
            </p>
            <Button
              onClick={() => setIsNewProjectDialogOpen(true)}
              className="w-full"
            >
              <PlusCircle className="mr-2 h-4 w-4" /> Create New Project
            </Button>
          </CardContent>
        </Card>

        <NewProjectDialog
          opened={isNewProjectDialogOpen}
          onClose={() => setIsNewProjectDialogOpen(false)}
        />
      </div>
    </>
  );
}
