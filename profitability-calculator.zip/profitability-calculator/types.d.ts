type ItemType = "fixed" | "percentage";

type OperationType = "multiply" | "divide" | "add" | "subtract";

type ItemFile = {
  id: string;
  name: string;
  mimetype: string;
  file?: File;
  thumbnail: string | null;
  driveFileId?: string;
};

type Item = {
  id: string;
  name: string;
  amount: number;
  type: "fixed" | "percentage";
  relatedItemId?: string;
  percentage?: number;
  files: ItemFile[];
  note?: string;
  locked: boolean;
};

type IncomeItem = Item & {
  schedule: string;
  nia: number;
  paA: number;
  pmA: number;
};

type Category = {
  id: string;
  name: string;
  type: "expense" | "income" | "capital";
  items: (Item | IncomeItem)[];
  locked: boolean;
};

type FinanceDetail = {
  id: string;
  name: string;
  value: number;
  operation?: OperationType;
};

type CapitalInvestment = {
  id: string;
  name: string;
  amount: number;
  percentage: number;
  financeDetails: FinanceDetail[];
};

type Project = {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  address: string;
  files: ItemFile[];
  categories: Category[];
  customerName: string;
  customerEmail: string;
  customerContact: string;
  capitalInvestments: CapitalInvestment[];
};
