// lib/client-db.ts
"use client";

import {
  saveProject,
  updateProject,
  loadProjects,
  loadFullProject,
  deleteProject,
} from "@/lib/actions";
import { toast } from "@/hooks/use-toast";

function createFormDataFromProject(project: Project): FormData {
  const formData = new FormData();
  formData.append("projectData", JSON.stringify(project));

  // Append project files
  project.files.forEach((file, index) => {
    if (file.file instanceof File) {
      formData.append(
        `projectFiles`,
        file.file,
        `project_${index}_${file.name}`
      );
    }
  });

  // Append category item files
  project.categories.forEach((category, catIndex) => {
    category.items.forEach((item, itemIndex) => {
      item.files.forEach((file, fileIndex) => {
        if (file.file instanceof File) {
          formData.append(
            `categoryFiles`,
            file.file,
            `category_${catIndex}_item_${itemIndex}_file_${fileIndex}_${file.name}`
          );
        }
      });
    });
  });

  return formData;
}

export const firebaseDB = {
  saveProject: async (project: Project) => {
    try {
      const formData = createFormDataFromProject(project);
      const response = await saveProject(formData);

      if (response.success) {
        toast({
          title: "Project saved",
          description: "Your project has been successfully saved.",
        });
        return { success: true, data: response.data };
      } else {
        throw new Error(response.error || "Failed to save project");
      }
    } catch (error) {
      console.error("Error saving project:", error);
      toast({
        title: "Error",
        description: "Failed to save project. Please try again.",
        variant: "destructive",
      });
      return { success: false, error: (error as Error).message };
    }
  },

  updateProject: async (projectId: string, updates: Partial<Project>) => {
    try {
      const formData = createFormDataFromProject(updates as Project);
      formData.append("projectId", projectId);
      const response = await updateProject(formData);

      if (response.success) {
        toast({
          title: "Project updated",
          description: "Your project has been successfully updated.",
        });
        return { success: true, data: response.data };
      } else {
        throw new Error(response.error || "Failed to update project");
      }
    } catch (error) {
      console.error("Error updating project:", error);
      toast({
        title: "Error",
        description: "Failed to update project. Please try again.",
        variant: "destructive",
      });
      return { success: false, error: (error as Error).message };
    }
  },

  loadProjects: async (limit: number = 10) => {
    try {
      const response = await loadProjects(limit);

      if (response.success) {
        return { success: true, data: response.data };
      } else {
        throw new Error(response.error || "Failed to load projects");
      }
    } catch (error) {
      console.error("Error loading projects:", error);
      toast({
        title: "Error",
        description: "Failed to load projects. Please try again.",
        variant: "destructive",
      });
      return { success: false, error: (error as Error).message };
    }
  },

  loadFullProject: async (projectId: string) => {
    try {
      const response = await loadFullProject(projectId);

      if (response.success) {
        return { success: true, data: response.data };
      } else {
        throw new Error(response.error || "Failed to load project");
      }
    } catch (error) {
      console.error("Error loading full project:", error);
      toast({
        title: "Error",
        description: "Failed to load project details. Please try again.",
        variant: "destructive",
      });
      return { success: false, error: (error as Error).message };
    }
  },

  deleteProject: async (projectId: string) => {
    try {
      const response = await deleteProject(projectId);

      if (response.success) {
        toast({
          title: "Project deleted",
          description: "Your project has been successfully deleted.",
        });
        return { success: true };
      } else {
        throw new Error(response.error || "Failed to delete project");
      }
    } catch (error) {
      console.error("Error deleting project:", error);
      toast({
        title: "Error",
        description: "Failed to delete project. Please try again.",
        variant: "destructive",
      });
      return { success: false, error: (error as Error).message };
    }
  },
};
