"use server";

import { initializeApp } from "firebase/app";
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  query,
  limit,
  deleteDoc,
} from "firebase/firestore";
import { google } from "googleapis";
import { JWT } from "google-auth-library";
import { revalidatePath } from "next/cache";
import { Readable } from "node:stream";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA4ThDBsOP0i86QCD_4GQXburqrXI1jNnE",
  authDomain: "profitability-calculator-b5de8.firebaseapp.com",
  projectId: "profitability-calculator-b5de8",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Google Drive API setup
const SCOPES = ["https://www.googleapis.com/auth/drive.file"];
const auth = new JWT({
  email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
  key: process.env.GOOGLE_PRIVATE_KEY!.split(String.raw`\n`).join("\n"),
  scopes: SCOPES,
});

const drive = google.drive({ version: "v3", auth });

// Helper function to upload file to Google Drive
async function uploadFileToDrive(file: File): Promise<string> {
  const fileMetadata = {
    name: file.name,
    parents: [process.env.GOOGLE_DRIVE_FOLDER_ID!],
  };

  const media = {
    mimeType: file.type,
    body: Readable.from(file.stream() as unknown as Iterable<never>),
  };

  try {
    const response = await drive.files.create({
      requestBody: fileMetadata,
      media: media,
      fields: "id",
    });

    return response.data.id as string;
  } catch (error) {
    console.error("Error uploading file to Google Drive:", error);
    throw error;
  }
}

// Helper function to delete file from Google Drive
async function deleteFileFromDrive(fileId: string): Promise<void> {
  try {
    const response = await drive.files.delete({ fileId });
    console.log("removed file ? ", response);
  } catch (error) {
    console.error("Error deleting file from Google Drive:", error);
    throw error;
  }
}

// Helper function to get download link from Google Drive
export async function getDownloadLink(fileId: string): Promise<string | null> {
  try {
    const result = await drive.files.get({
      fileId: fileId,
      fields: "webContentLink",
    });

    console.log("webContentLink: ", result.data.webContentLink);

    return result.data.webContentLink || "";
  } catch (error) {
    console.error("Error getting download link:", error);
    return null;
  }
}

async function getThumbnailLink(fileId: string): Promise<string | null> {
  try {
    const result = await drive.files.get({
      fileId: fileId,
      fields: "thumbnailLink",
    });

    console.log("thumbnail: ", result.data.thumbnailLink);

    return result.data.thumbnailLink || "";
  } catch (error) {
    console.error("Error getting thumbnail link:", error);
    return null;
  }
}

export async function saveProject(formData: FormData) {
  try {
    const projectData = JSON.parse(
      formData.get("projectData") as string
    ) as Project;
    const projectFiles = formData.getAll("projectFiles") as File[];
    const categoryFiles = formData.getAll("categoryFiles") as File[];

    // Handle project file uploads
    const updatedFiles = await Promise.all(
      projectData.files.map(async (file, index) => {
        if (projectFiles[index]) {
          console.log("Uploading project file to drive");
          const driveFileId = await uploadFileToDrive(projectFiles[index]);
          const thumbnailLink = await getThumbnailLink(driveFileId);

          return {
            ...file,
            driveFileId,
            thumbnail: thumbnailLink,
          };
        }
        return file;
      })
    );

    // Handle category item file uploads
    let categoryFileIndex = 0;
    const updatedCategories = await Promise.all(
      projectData.categories.map(async (category) => {
        const updatedItems = await Promise.all(
          category.items.map(async (item) => {
            const updatedFiles = await Promise.all(
              item.files.map(async (file) => {
                if (categoryFiles[categoryFileIndex]) {
                  console.log("Uploading category file to drive");
                  const driveFileId = await uploadFileToDrive(
                    categoryFiles[categoryFileIndex]
                  );
                  const thumbnailLink = await getThumbnailLink(driveFileId);

                  categoryFileIndex++;
                  return { ...file, driveFileId, thumbnail: thumbnailLink };
                }
                return file;
              })
            );
            return { ...item, files: updatedFiles };
          })
        );
        return { ...category, items: updatedItems };
      })
    );

    // Update project with new file information
    const updatedProject = {
      ...projectData,
      files: updatedFiles,
      categories: updatedCategories,
    };

    await setDoc(doc(db, "projects", projectData.id), updatedProject);
    revalidatePath(`/${projectData.id}`);
    return { data: updatedProject, success: true };
  } catch (error) {
    console.error("Error saving project: ", error);
    return { success: false, error: "Failed to save project" };
  }
}

export async function updateProject(formData: FormData) {
  try {
    const projectId = formData.get("projectId") as string;
    const updates = JSON.parse(
      formData.get("projectData") as string
    ) as Partial<Project>;
    const projectFiles = formData.getAll("projectFiles") as File[];
    const categoryFiles = formData.getAll("categoryFiles") as File[];

    const projectRef = doc(db, "projects", projectId);
    const projectSnap = await getDoc(projectRef);

    if (!projectSnap.exists()) {
      throw new Error("Project not found");
    }

    const currentProject = projectSnap.data() as Project;

    // Handle file uploads and deletions
    if (updates.files) {
      let fileIndex = 0;
      const updatedFiles = await Promise.all(
        updates.files.map(async (file) => {
          if (projectFiles[fileIndex]) {
            const driveFileId = await uploadFileToDrive(
              projectFiles[fileIndex]
            );
            const thumbnailLink = await getThumbnailLink(driveFileId);
            fileIndex++;
            return { ...file, driveFileId, thumbnail: thumbnailLink };
          }
          return file;
        })
      );

      // Delete files that are no longer in the project
      const filesToDelete = currentProject.files.filter(
        (file) =>
          !updatedFiles.some((updatedFile) => updatedFile.id === file.id)
      );

      console.log("filesToDelete: ", filesToDelete);

      await Promise.all(
        filesToDelete.map((file) =>
          file.driveFileId
            ? deleteFileFromDrive(file.driveFileId)
            : Promise.resolve()
        )
      );

      updates.files = updatedFiles;
    }

    // Handle files in categories if categories are being updated
    if (updates.categories) {
      let categoryFileIndex = 0;
      updates.categories = await Promise.all(
        updates.categories.map(async (category) => {
          const updatedItems = await Promise.all(
            category.items.map(async (item) => {
              const updatedFiles = await Promise.all(
                item.files.map(async (file) => {
                  if (categoryFiles[categoryFileIndex]) {
                    const driveFileId = await uploadFileToDrive(
                      categoryFiles[categoryFileIndex]
                    );
                    const thumbnailLink = await getThumbnailLink(driveFileId);
                    categoryFileIndex++;
                    return { ...file, driveFileId, thumbnail: thumbnailLink };
                  }
                  return file;
                })
              );

              // Delete files that are no longer in the item
              const currentItem = currentProject.categories
                .find((c) => c.id === category.id)
                ?.items.find((i) => i.id === item.id);

              if (currentItem) {
                const filesToDelete = currentItem.files.filter(
                  (file) =>
                    !updatedFiles.some(
                      (updatedFile) => updatedFile.id === file.id
                    )
                );

                await Promise.all(
                  filesToDelete.map((file) =>
                    file.driveFileId
                      ? deleteFileFromDrive(file.driveFileId)
                      : Promise.resolve()
                  )
                );
              }

              return { ...item, files: updatedFiles };
            })
          );
          return { ...category, items: updatedItems };
        })
      );
    }

    const updatedProject = { ...currentProject, ...updates };
    await updateDoc(projectRef, updatedProject);
    revalidatePath(`/${projectId}`);
    return { success: true, data: updatedProject };
  } catch (error) {
    console.error("Error updating project: ", error);
    return { success: false, error: "Failed to update project" };
  }
}

export async function loadProjects(limitCount: number = 10) {
  try {
    const projectsQuery = query(collection(db, "projects"), limit(limitCount));
    const querySnapshot = await getDocs(projectsQuery);
    const projects = querySnapshot.docs.map((doc) => doc.data() as Project);
    return { success: true, data: projects };
  } catch (error) {
    console.error("Error loading projects: ", error);
    return { success: false, error: "Failed to load projects" };
  }
}

export async function loadFullProject(projectId: string) {
  try {
    const docSnap = await getDoc(doc(db, "projects", projectId));
    if (docSnap.exists()) {
      const project = docSnap.data() as Project;
      return { success: true, data: project };
    } else {
      return { success: false, error: "Project not found" };
    }
  } catch (error) {
    console.error("Error loading full project: ", error);
    return { success: false, error: "Failed to load project" };
  }
}

export async function deleteProject(projectId: string) {
  try {
    const projectRef = doc(db, "projects", projectId);
    const projectSnap = await getDoc(projectRef);

    if (!projectSnap.exists()) {
      throw new Error("Project not found");
    }

    const project = projectSnap.data() as Project;

    // Delete all files associated with the project
    const deleteFilePromises = project.files
      .filter((file) => file.driveFileId)
      .map((file) => deleteFileFromDrive(file.driveFileId!));

    // Delete files in categories
    project.categories.forEach((category) => {
      category.items.forEach((item) => {
        item.files
          .filter((file) => file.driveFileId)
          .forEach((file) =>
            deleteFilePromises.push(deleteFileFromDrive(file.driveFileId!))
          );
      });
    });

    await Promise.all(deleteFilePromises);

    // Delete the project document
    await deleteDoc(projectRef);
    revalidatePath(`/${projectId}`);
    return { success: true };
  } catch (error) {
    console.error("Error deleting project: ", error);
    return { success: false, error: "Failed to delete project" };
  }
}
