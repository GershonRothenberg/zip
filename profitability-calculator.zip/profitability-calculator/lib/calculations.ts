export const calculateItemAmount = (
  item: Item | IncomeItem,
  allItems: (Item | IncomeItem)[]
): number => {
  if (item.type === "fixed") {
    return item.amount;
  } else if (
    item.type === "percentage" &&
    item.relatedItemId &&
    item.percentage
  ) {
    const relatedItem = allItems.find((i) => i.id === item.relatedItemId);

    if (relatedItem?.type === "percentage") {
      return (
        (calculateItemAmount(relatedItem, allItems) * item.percentage) / 100
      );
    }

    return relatedItem ? (relatedItem.amount * item.percentage) / 100 : 0;
  }

  return 0;
};
