"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { getDownloadLink } from "@/lib/actions";
import { format } from "date-fns";
import {
  Calendar,
  Download,
  Edit,
  ExternalLink,
  Eye,
  FileText,
  MapPin,
  X,
} from "lucide-react";
import React, { useEffect, useState } from "react";
import Loader from "./ui/loader";

type ProjectDetailsProps = {
  project: Project;
  updateProject: (updates: Partial<Project>) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  financialSummary: {
    totalIncome: number;
    totalExpenses: number;
    netOperatingIncome: number;
    capitalInvestment: number;
  };
};

export function ProjectDetails({
  project,
  updateProject,
  isOpen,
  setIsOpen,
  financialSummary,
}: ProjectDetailsProps) {
  const [editedProject, setEditedProject] = useState<Project>(project);
  const [isEditing, setIsEditing] = useState(false);
  const [addressError, setAddressError] = useState<string | null>(null);
  const [preparingDownloadId, setPreparingDownloadId] = useState<string | null>(
    null
  );

  useEffect(() => {
    setEditedProject(project);
  }, [project]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setEditedProject((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files).map((file) => ({
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        name: file.name,
        file: file,
        mimetype: file.type,
        thumbnail: file.type.startsWith("image/")
          ? URL.createObjectURL(file)
          : null,
      }));
      setEditedProject((prev) => ({
        ...prev,
        files: [...prev.files, ...newFiles],
      }));
    }
  };

  const handleSave = async () => {
    if (
      editedProject.address &&
      !(await validateAddress(editedProject.address))
    ) {
      return;
    }

    updateProject(editedProject);
    setIsEditing(false);
    toast({
      title: "Changes Saved",
      description: "Your project details have been updated.",
    });
  };

  const handleCancel = () => {
    setEditedProject(project);
    setIsEditing(false);
    setAddressError(null);
  };

  const handleDeleteFile = (fileId: string) => {
    const updatedFiles = editedProject.files.filter(
      (file) => file.id !== fileId
    );
    setEditedProject((prev) => ({ ...prev, files: updatedFiles }));
  };

  const validateAddress = async (address: string): Promise<boolean> => {
    const googleMapsUrlRegex =
      /^https:\/\/(www\.)?google\.com\/maps\/(place\/)?([^\/]+\/)?@(-?\d+\.\d+),(-?\d+\.\d+),\d+z/i;
    const isValid = googleMapsUrlRegex.test(address);
    if (!isValid) {
      setAddressError("Please enter a valid Google Maps URL");
      return false;
    }
    setAddressError(null);
    return true;
  };

  const handleDownloadFile = async (file: ItemFile) => {
    setPreparingDownloadId(file.id);

    const url = file.thumbnail as string;
    const a = document.createElement("a");
    a.href = url;
    if (file.driveFileId) {
      const downloadLink = await getDownloadLink(file.driveFileId);
      a.href = downloadLink ?? url;
    }
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setPreparingDownloadId(null);
  };

  const renderFilePreview = (file: ItemFile) => {
    if (file.name.endsWith("png")) {
      return (
        <img
          src={file.thumbnail || ""}
          alt={file.name}
          className="w-full h-32 object-cover mb-2 rounded"
        />
      );
    } else {
      return (
        <div className="w-full h-32 bg-muted flex items-center justify-center mb-2 rounded">
          <FileText className="h-8 w-8 text-muted-foreground" />
        </div>
      );
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[700px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold flex justify-between items-center">
            Project Details
            <Button
              onClick={() => setIsEditing(!isEditing)}
              variant="outline"
              size="sm"
              className="mr-6"
            >
              {isEditing ? (
                <Eye className="mr-2 h-4 w-4" />
              ) : (
                <Edit className="mr-2 h-4 w-4" />
              )}
              {isEditing ? "Display" : "Edit"}
            </Button>
          </DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[calc(80vh-180px)] pr-4">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">
                  Project Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-sm text-muted-foreground flex items-center">
                    <Calendar className="mr-2 h-4 w-4" />
                    Created:{" "}
                    {format(new Date(project.createdAt), "MMMM d, yyyy")}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="name">Project Name</Label>
                    <Input
                      id="name"
                      name="name"
                      value={editedProject.name}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      name="description"
                      value={editedProject.description}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address">Address (Google Maps URL)</Label>
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <Input
                        id="address"
                        name="address"
                        value={editedProject.address}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                        placeholder="https://www.google.com/maps/place/..."
                      />
                      {editedProject.address && (
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() =>
                            window.open(editedProject.address, "_blank")
                          }
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    {addressError && (
                      <p className="text-sm text-red-500">{addressError}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="customerName">Customer Name</Label>
                    <Input
                      id="customerName"
                      name="customerName"
                      value={editedProject.customerName}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="customerEmail">Customer Email</Label>
                    <Input
                      id="customerEmail"
                      name="customerEmail"
                      type="email"
                      value={editedProject.customerEmail}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="customerContact">Customer Contact</Label>
                    <Input
                      id="customerContact"
                      name="customerContact"
                      value={editedProject.customerContact}
                      onChange={handleInputChange}
                      disabled={!isEditing}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">
                  Project Files
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isEditing && (
                  <div className="mb-4">
                    <Label htmlFor="files">Add New Files</Label>
                    <Input
                      id="files"
                      type="file"
                      onChange={handleFileChange}
                      multiple
                      className="mt-2"
                    />
                  </div>
                )}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {editedProject.files.map((file) => (
                    <Card key={file.id} className="overflow-hidden">
                      <CardContent className="p-2">
                        {renderFilePreview(file)}
                        <div className="flex justify-between items-center">
                          <span className="text-sm truncate">{file.name}</span>
                          <div className="flex space-x-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDownloadFile(file)}
                              disabled={preparingDownloadId === file.id}
                            >
                              {preparingDownloadId === file.id ? (
                                <Loader />
                              ) : (
                                <Download className="h-4 w-4" />
                              )}
                              <span className="sr-only">Download file</span>
                            </Button>
                            {isEditing && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDeleteFile(file.id)}
                              >
                                <X className="h-4 w-4" />
                                <span className="sr-only">Delete file</span>
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">
                  Financial Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Total Income</p>
                    <p className="text-2xl font-bold">
                      ${financialSummary.totalIncome.toLocaleString()}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Total Expenses</p>
                    <p className="text-2xl font-bold">
                      ${financialSummary.totalExpenses.toLocaleString()}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Net Operating Income</p>
                    <p className="text-2xl font-bold">
                      ${financialSummary.netOperatingIncome.toLocaleString()}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Capital Investment</p>
                    <p className="text-2xl font-bold">
                      ${financialSummary.capitalInvestment.toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </ScrollArea>
      </DialogContent>
      <DialogFooter className="flex gap-2 justify-end">
        {isEditing && (
          <>
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button onClick={handleSave}>Save Changes</Button>
          </>
        )}
      </DialogFooter>
    </Dialog>
  );
}
