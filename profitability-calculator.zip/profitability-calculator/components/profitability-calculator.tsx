"use client";

import { loadFullProject } from "@/lib/actions";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { CapitalInvestmentSection } from "./capital-investment-section";
import { CategorySection } from "./category-section";
import { FinancialSummary } from "./financial-summary";
import { ProjectDetails } from "./project-details";
import { ProjectHeader } from "./project-header";
import Loader from "./ui/loader";

export default function ProfitabilityCalculator() {
  const params = useParams();
  const currentProjectId = params.projectId as string;

  const [currentProject, setCurrentProject] = useState<Project>();
  const [defaultProject, setDefaultProject] = useState<Project>();
  const [isProjectDetailsOpen, setIsProjectDetailsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    loadFullProject(currentProjectId)
      .then((response) => {
        setCurrentProject(response.data);
        setDefaultProject(response.data);
      })
      .finally(() => setIsLoading(false));
  }, []);

  const onRefetch = () => {
    loadFullProject(currentProjectId).then((response) => {
      setCurrentProject(response.data);
      setDefaultProject(response.data);
    });
  };

  console.log("currentProject: ", currentProject);

  if (isLoading) {
    return <h1>Loading...</h1>;
  }

  if (!currentProject || !defaultProject) {
    return (
      <div className="w-full h-screen grid place-items-center">
        <Loader className="w-8 h-8" />
      </div>
    );
  }

  const updateProject = (updates: Partial<Project>) => {
    if (!currentProject) return;

    setCurrentProject((prevProjects) => ({ ...prevProjects!, ...updates }));
  };

  const calculateFinancialSummary = (project: Project) => {
    const totalIncome = project.categories
      .filter((category) => category.type === "income")
      .flatMap((category) => category.items)
      .reduce((sum, item) => sum + item.amount, 0);

    const totalExpenses = project.categories
      .filter((category) => category.type === "expense")
      .flatMap((category) => category.items)
      .reduce((sum, item) => sum + item.amount, 0);

    const netOperatingIncome = totalIncome - totalExpenses;

    const capitalInvestment = project.capitalInvestments.reduce(
      (sum, investment) => sum + investment.amount,
      0
    );

    return {
      totalIncome,
      totalExpenses,
      netOperatingIncome,
      capitalInvestment,
    };
  };

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <img
            src="/placeholder.svg?height=50&width=200"
            alt="Logo"
            className="h-12"
          />
        </div>

        <h1 className="text-3xl font-bold">Profitability Calculator</h1>
      </div>

      <ProjectHeader
        onRefetch={onRefetch}
        defaultProject={defaultProject}
        currentProject={currentProject}
        updateProject={updateProject}
        setIsProjectDetailsOpen={setIsProjectDetailsOpen}
      />
      {currentProject && (
        <>
          <CategorySection
            project={currentProject}
            updateProject={updateProject}
          />

          <CapitalInvestmentSection
            project={currentProject}
            updateProject={updateProject}
          />

          <FinancialSummary project={currentProject} />
        </>
      )}
      {currentProject && (
        <ProjectDetails
          project={currentProject}
          updateProject={updateProject}
          isOpen={isProjectDetailsOpen}
          setIsOpen={setIsProjectDetailsOpen}
          financialSummary={calculateFinancialSummary(currentProject)}
        />
      )}
    </>
  );
}
