import React, { useState } from "react";
import { PlusCircle, X, Settings, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

type CapitalInvestmentSectionProps = {
  project: Project;
  updateProject: (updates: Partial<Project>) => void;
};

export function CapitalInvestmentSection({
  project,
  updateProject,
}: CapitalInvestmentSectionProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const addCapitalInvestment = () => {
    const newInvestment = {
      id: Date.now().toString(),
      name: "New Investment",
      amount: 0,
      percentage: 0,
      financeDetails: [],
    };
    updateProject({
      capitalInvestments: [...project.capitalInvestments, newInvestment],
    });
  };

  const updateCapitalInvestment = (
    id: string,
    updates: Partial<CapitalInvestment>
  ) => {
    updateProject({
      capitalInvestments: project.capitalInvestments.map((investment) =>
        investment.id === id ? { ...investment, ...updates } : investment
      ),
    });
  };

  const removeCapitalInvestment = (id: string) => {
    updateProject({
      capitalInvestments: project.capitalInvestments.filter(
        (investment) => investment.id !== id
      ),
    });
  };

  const addFinanceDetail = (investmentId: string) => {
    updateProject({
      capitalInvestments: project.capitalInvestments.map((investment) =>
        investment.id === investmentId
          ? {
              ...investment,
              financeDetails: [
                ...investment.financeDetails,
                {
                  id: Date.now().toString(),
                  name: "",
                  value: 0,
                  operation: "add",
                },
              ],
            }
          : investment
      ),
    });
  };

  const updateFinanceDetail = (
    investmentId: string,
    detailId: string,
    updates: Partial<FinanceDetail>
  ) => {
    updateProject({
      capitalInvestments: project.capitalInvestments.map((investment) =>
        investment.id === investmentId
          ? {
              ...investment,
              financeDetails: investment.financeDetails.map((detail) =>
                detail.id === detailId ? { ...detail, ...updates } : detail
              ),
            }
          : investment
      ),
    });
  };

  const removeFinanceDetail = (investmentId: string, detailId: string) => {
    updateProject({
      capitalInvestments: project.capitalInvestments.map((investment) =>
        investment.id === investmentId
          ? {
              ...investment,
              financeDetails: investment.financeDetails.filter(
                (detail) => detail.id !== detailId
              ),
            }
          : investment
      ),
    });
  };

  const calculateFinanceDetailsTotal = (
    financeDetails: FinanceDetail[]
  ): number => {
    let total = 0;
    for (let i = 0; i < financeDetails.length; i++) {
      const detail = financeDetails[i];
      if (i === 0) {
        total = detail.value;
      } else {
        switch (detail.operation) {
          case "add":
            total += detail.value;
            break;
          case "subtract":
            total -= detail.value;
            break;
          case "multiply":
            total *= detail.value;
            break;
          case "divide":
            if (detail.value !== 0) {
              total /= detail.value;
            }
            break;
          default:
            total += detail.value;
        }
      }
    }
    return total;
  };

  const calculateTotal = (type: "expense" | "income" | "capital") => {
    let total = 0;

    // Calculate total from categories
    const allItems = project.categories.flatMap((c) => c.items);

    total += project.categories
      .filter((category) => category.type === type)
      .reduce((categoryTotal, category) => {
        return (
          categoryTotal +
          category.items.reduce((sum, item) => {
            return sum + calculateItemAmount(item, allItems);
          }, 0)
        );
      }, 0);

    // Add capital investments to the total if the type is 'capital'
    if (type === "capital" || type === "expense") {
      total += project.capitalInvestments.reduce(
        (sum, investment) => sum + investment.amount,
        0
      );
    }

    return total;
  };

  const calculateItemAmount = (
    item: Item | IncomeItem,
    allItems: (Item | IncomeItem)[]
  ): number => {
    if (item.type === "fixed") {
      return item.amount;
    } else if (
      item.type === "percentage" &&
      item.relatedItemId &&
      item.percentage
    ) {
      const relatedItem = allItems.find((i) => i.id === item.relatedItemId);

      if (relatedItem?.type === "percentage") {
        return (
          (calculateItemAmount(relatedItem, allItems) * item.percentage) / 100
        );
      }

      return relatedItem ? (relatedItem.amount * item.percentage) / 100 : 0;
    }

    return 0;
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Capital Investment</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? (
              <ChevronUp className="h-4 w-4" />
            ) : (
              <ChevronDown className="h-4 w-4" />
            )}
          </Button>
        </CardTitle>
      </CardHeader>
      {isExpanded && (
        <CardContent>
          <Button onClick={addCapitalInvestment} size="sm" className="mb-4">
            <PlusCircle className="h-4 w-4 mr-2" /> Add Investment
          </Button>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Percentage</TableHead>
                <TableHead>Calculated Value</TableHead>
                <TableHead>Finance Details</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {project.capitalInvestments.map((investment) => (
                <TableRow key={investment.id}>
                  <TableCell>
                    <Input
                      value={investment.name}
                      onChange={(e) =>
                        updateCapitalInvestment(investment.id, {
                          name: e.target.value,
                        })
                      }
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={investment.amount}
                      onChange={(e) =>
                        updateCapitalInvestment(investment.id, {
                          amount: parseFloat(e.target.value) || 0,
                        })
                      }
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={investment.percentage}
                      onChange={(e) => {
                        const newPercentage = parseFloat(e.target.value) || 0;
                        const newAmount =
                          (newPercentage / 100) * calculateTotal("capital");
                        updateCapitalInvestment(investment.id, {
                          percentage: newPercentage,
                          amount: newAmount,
                        });
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    $
                    {(
                      (investment.percentage / 100) *
                      calculateTotal("capital")
                    ).toFixed(2)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <span>
                        $
                        {calculateFinanceDetailsTotal(
                          investment.financeDetails
                        ).toFixed(2)}
                      </span>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            <Settings className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>
                              Finance Details for {investment.name}
                            </DialogTitle>
                          </DialogHeader>
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Name</TableHead>
                                <TableHead>Value</TableHead>
                                <TableHead>Operation</TableHead>
                                <TableHead>Actions</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {investment.financeDetails.map(
                                (detail, index) => (
                                  <TableRow key={detail.id}>
                                    <TableCell>
                                      <Input
                                        value={detail.name}
                                        onChange={(e) =>
                                          updateFinanceDetail(
                                            investment.id,
                                            detail.id,
                                            { name: e.target.value }
                                          )
                                        }
                                        placeholder="Detail Name"
                                      />
                                    </TableCell>
                                    <TableCell>
                                      <Input
                                        type="number"
                                        value={detail.value}
                                        onChange={(e) =>
                                          updateFinanceDetail(
                                            investment.id,
                                            detail.id,
                                            {
                                              value:
                                                parseFloat(e.target.value) || 0,
                                            }
                                          )
                                        }
                                        placeholder="Value"
                                      />
                                    </TableCell>
                                    <TableCell>
                                      {index > 0 && (
                                        <Select
                                          value={detail.operation}
                                          onValueChange={(value) => {
                                            updateFinanceDetail(
                                              investment.id,
                                              detail.id,
                                              {
                                                operation:
                                                  value as OperationType,
                                              }
                                            );
                                          }}
                                        >
                                          <SelectTrigger>
                                            <SelectValue placeholder="Select operation" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="add">
                                              Add
                                            </SelectItem>
                                            <SelectItem value="subtract">
                                              Subtract
                                            </SelectItem>
                                            <SelectItem value="multiply">
                                              Multiply
                                            </SelectItem>
                                            <SelectItem value="divide">
                                              Divide
                                            </SelectItem>
                                          </SelectContent>
                                        </Select>
                                      )}
                                    </TableCell>
                                    <TableCell>
                                      <Button
                                        onClick={() =>
                                          removeFinanceDetail(
                                            investment.id,
                                            detail.id
                                          )
                                        }
                                        size="sm"
                                        variant="ghost"
                                      >
                                        <X className="h-4 w-4" />
                                      </Button>
                                    </TableCell>
                                  </TableRow>
                                )
                              )}
                            </TableBody>
                          </Table>
                          <Button
                            onClick={() => addFinanceDetail(investment.id)}
                            size="sm"
                            className="mt-2"
                          >
                            <PlusCircle className="h-4 w-4 mr-2" /> Add Finance
                            Detail
                          </Button>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Button
                      onClick={() => removeCapitalInvestment(investment.id)}
                      size="sm"
                      variant="ghost"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <div className="mt-4 font-bold">
            Total Capital to Invest: ${calculateTotal("capital").toFixed(2)}
          </div>
        </CardContent>
      )}
    </Card>
  );
}
