"use client";

import React from "react";
import { Card, CardContent } from "@/components/ui/card";

type FinancialSummaryProps = {
  project: Project;
};

export function FinancialSummary({ project }: FinancialSummaryProps) {
  const calculateTotal = (type: "expense" | "income" | "capital") => {
    let total = 0;

    // Calculate total from categories
    const allItems = project.categories.flatMap((c) => c.items);

    total += project.categories
      .filter((category) => category.type === type)
      .reduce((categoryTotal, category) => {
        return (
          categoryTotal +
          category.items.reduce((sum, item) => {
            return sum + calculateItemAmount(item, allItems);
          }, 0)
        );
      }, 0);

    // Add capital investments to the total if the type is 'capital'
    if (type === "capital" || type === "expense") {
      total += project.capitalInvestments.reduce(
        (sum, investment) => sum + investment.amount,
        0
      );
    }

    return total;
  };

  const calculateItemAmount = (
    item: Item | IncomeItem,
    allItems: (Item | IncomeItem)[]
  ): number => {
    if (item.type === "fixed") {
      return item.amount;
    } else if (
      item.type === "percentage" &&
      item.relatedItemId &&
      item.percentage
    ) {
      const relatedItem = allItems.find((i) => i.id === item.relatedItemId);

      if (relatedItem?.type === "percentage") {
        return (
          (calculateItemAmount(relatedItem, allItems) * item.percentage) / 100
        );
      }

      return relatedItem ? (relatedItem.amount * item.percentage) / 100 : 0;
    }

    return 0;
  };

  const calculateAnticipatedProfit = () => {
    const totalIncome = calculateTotal("income");
    const totalExpenses = calculateTotal("expense");
    return totalIncome - totalExpenses;
  };

  const calculateYieldOn = (base: number) => {
    const anticipatedProfit = calculateAnticipatedProfit();
    return base !== 0 ? (anticipatedProfit / base) * 100 : 0;
  };

  const calculateERV = () => {
    return project.categories
      .filter((category) => category.type === "income")
      .reduce((total, category) => {
        console.log(category);

        return (
          total +
          (category.items as IncomeItem[]).reduce(
            (sum, item) => sum + item.paA,
            0
          )
        );
      }, 0);
  };

  const calculateNetIncomePA = () => {
    const anticipatedProfit = calculateAnticipatedProfit();
    const totalFinanceCosts =
      project.categories
        .find((category) => category.name === "Finance Costs")
        ?.items.reduce((sum, item) => sum + item.amount, 0) || 0;
    return anticipatedProfit - totalFinanceCosts;
  };

  return (
    <Card className="mt-6">
      <CardContent className="p-4">
        <h3 className="text-xl font-bold mb-4">Financial Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>Total Expenses: ${calculateTotal("expense").toFixed(2)}</div>
          <div>Total Income: ${calculateTotal("income").toFixed(2)}</div>
          <div>Total Capital: ${calculateTotal("capital").toFixed(2)}</div>
          <div>Net Profit: ${calculateAnticipatedProfit().toFixed(2)}</div>
          <div>
            Yield on Capital:{" "}
            {calculateYieldOn(calculateTotal("capital")).toFixed(2)}%
          </div>
          <div>
            Yield on Expenses:{" "}
            {calculateYieldOn(calculateTotal("expense")).toFixed(2)}%
          </div>
          <div>ERV (Estimated Rental Value): ${calculateERV().toFixed(2)}</div>
          <div>Net Income PA: ${calculateNetIncomePA().toFixed(2)}</div>
        </div>
      </CardContent>
    </Card>
  );
}
