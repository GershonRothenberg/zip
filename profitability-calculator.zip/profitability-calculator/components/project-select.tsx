"use client";

import { firebaseDB } from "@/lib/db";
import React, { useEffect, useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { toast } from "@/hooks/use-toast";
import { useParams, useRouter } from "next/navigation";

const ProjectSelect = () => {
  const router = useRouter();
  const params = useParams();

  const currentProjectId = params.projectId as string | undefined;

  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadProjects = async () => {
    setIsLoading(true);
    try {
      const savedProjects = await firebaseDB.loadProjects();
      if (savedProjects.data && savedProjects.data.length > 0) {
        setProjects(savedProjects.data);
        console.log("projects: ", savedProjects.data);
      } else {
        setProjects([]);
      }
    } catch (error) {
      console.error("Error loading projects:", error);
      toast({
        title: "Error",
        description: "Failed to load projects. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectProject = (projectId: string) => {
    router.push(`${projectId}`);
  };

  useEffect(() => {
    loadProjects();
  }, []);

  return (
    <div className="w-full sm:w-auto">
      <Select
        value={currentProjectId || ""}
        onValueChange={handleSelectProject}
      >
        <SelectTrigger className="w-full sm:w-[200px]">
          <SelectValue
            placeholder={isLoading ? "Loading projects..." : "Select a project"}
          />
        </SelectTrigger>
        <SelectContent>
          {projects.map((project) => (
            <SelectItem key={project.id} value={project.id}>
              {project.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default ProjectSelect;
