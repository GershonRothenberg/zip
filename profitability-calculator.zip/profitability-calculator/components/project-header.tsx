import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { firebaseDB } from "@/lib/db";
import { format } from "date-fns";
import { FileText, PlusCircle, Save } from "lucide-react";
import React, { useState } from "react";
import NewProjectDialog from "./new-project-dialog";
import ProjectSelect from "./project-select";
import Loader from "./ui/loader";

type ProjectHeaderProps = {
  onRefetch: () => void;
  defaultProject: Project;
  currentProject: Project;
  updateProject: (updates: Partial<Project>) => void;
  setIsProjectDetailsOpen: (isOpen: boolean) => void;
};

function DefaultProjectHeader({
  onRefetch,
  defaultProject,
  currentProject,
  setIsProjectDetailsOpen,
}: ProjectHeaderProps) {
  const [isNewProjectDialogOpen, setIsNewProjectDialogOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const isDirty =
    JSON.stringify(currentProject) !== JSON.stringify(defaultProject);

  const saveProject = async () => {
    setIsSaving(true);
    try {
      await firebaseDB.updateProject(currentProject.id, currentProject!);
      toast({
        title: "Project saved successfully",
        description: "Your project data has been saved.",
      });
      onRefetch();
    } catch (error) {
      console.error("Error saving projects:", error);
      toast({
        title: "Error",
        description: "Failed to save project. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex flex-col space-y-4 mb-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
        <div className="w-full sm:w-auto">
          <ProjectSelect />
        </div>
        <Button
          onClick={() => setIsNewProjectDialogOpen(true)}
          className="w-full sm:w-auto"
        >
          <PlusCircle className="h-4 w-4 mr-2" />
          New Project
        </Button>
      </div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
        {currentProject && (
          <div className="text-sm text-gray-500 w-full sm:w-auto">
            Created:{" "}
            {format(new Date(currentProject.createdAt), "MMMM d, yyyy")}
          </div>
        )}
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 w-full sm:w-auto">
          <Button
            onClick={() => setIsProjectDetailsOpen(true)}
            variant="outline"
            className="w-full sm:w-auto"
          >
            <FileText className="mr-2 h-4 w-4" />
            Project Details
          </Button>
          <Button
            onClick={saveProject}
            className="w-full sm:w-auto"
            disabled={isSaving || !isDirty}
          >
            {isSaving ? (
              <Loader className="mr-2" />
            ) : (
              <Save className="mr-2 h-4 w-4" />
            )}
            Save Project
          </Button>
        </div>
      </div>

      <NewProjectDialog
        opened={isNewProjectDialogOpen}
        onClose={() => setIsNewProjectDialogOpen(false)}
      />
    </div>
  );
}

export const ProjectHeader = React.memo(DefaultProjectHeader);
