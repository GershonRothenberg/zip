"use client";

import React, { useState } from "react";

import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useRouter } from "next/navigation";
import { Button } from "./ui/button";
import { toast } from "@/hooks/use-toast";
import { firebaseDB } from "@/lib/db";

type NewProjectDialogProps = {
  opened: boolean;
  onClose: () => void;
};

const NewProjectDialog = ({ opened, onClose }: NewProjectDialogProps) => {
  const router = useRouter();

  const [newProjectName, setNewProjectName] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const createNewProject = async (name: string) => {
    const newProject: Project = {
      id: Date.now().toString(),
      name: name,
      description: "A new project description.",
      createdAt: new Date().toISOString(),
      address: "",
      customerName: "",
      customerEmail: "",
      customerContact: "",
      files: [],
      categories: [
        {
          id: "1",
          name: "Operating Expenses",
          type: "expense",
          items: [
            {
              id: "e1",
              name: "Property Management",
              amount: 36000,
              type: "fixed",
              locked: true,
              files: [],
            },
            {
              id: "e2",
              name: "Insurance",
              amount: 12000,
              type: "fixed",
              locked: true,
              files: [],
            },
            {
              id: "e3",
              name: "Repairs and Maintenance",
              amount: 24000,
              type: "fixed",
              locked: true,
              files: [],
            },
            {
              id: "e4",
              name: "Other Expenses",
              amount: 18000,
              type: "fixed",
              locked: true,
              files: [],
            },
          ],
          locked: false,
        },
        {
          id: "2",
          name: "Finance Costs",
          type: "expense",
          items: [
            {
              id: "f1",
              name: "Finance Expenses",
              amount: 240000,
              type: "fixed",
              locked: true,
              files: [],
            },
          ],
          locked: false,
        },
        {
          id: "3",
          name: "Income Streams",
          type: "income",
          items: [
            {
              id: "i1",
              name: "Rental Income",
              amount: 1200000,
              type: "fixed",
              schedule: "Monthly",
              nia: 90000,
              pmA: 100000,
              paA: 1200000,
              locked: true,
              files: [],
            } as IncomeItem,
          ],
          locked: false,
        },
      ],
      capitalInvestments: [
        {
          id: "c1",
          name: "Purchase",
          amount: 10000000,
          percentage: 83.33,
          financeDetails: [
            { id: "fd1", name: "Amount", value: 7000000 },
            { id: "fd3", name: "Term (Years)", value: 30, operation: "divide" },
          ],
        },
        {
          id: "c2",
          name: "Construction",
          amount: 1000000,
          percentage: 8.33,
          financeDetails: [
            { id: "fd4", name: "Amount", value: 800000 },
            { id: "fd6", name: "Term (Years)", value: 5, operation: "divide" },
          ],
        },
        {
          id: "c3",
          name: "Other Expenses",
          amount: 1000000,
          percentage: 8.33,
          financeDetails: [],
        },
      ],
    };

    setIsLoading(true);
    const response = await firebaseDB.saveProject(newProject);
    setIsLoading(false);

    return response.data;
  };

  const handleCreateNewProject = async () => {
    if (newProjectName.trim() === "") {
      toast({
        title: "Error",
        description: "Project name cannot be empty.",
        variant: "destructive",
      });
      return;
    }

    const project = await createNewProject(newProjectName);
    if (project?.id) {
      router.push(`/${project.id}`);
    }

    setNewProjectName("");
  };

  return (
    <Dialog open={opened} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Project</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <Label htmlFor="projectName">Project Name</Label>
          <Input
            id="projectName"
            value={newProjectName}
            onChange={(e) => setNewProjectName(e.target.value)}
            placeholder="Enter project name"
          />
        </div>
        <DialogFooter>
          <Button onClick={handleCreateNewProject} disabled={isLoading}>
            {isLoading ? "Loading..." : "Create Project"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default NewProjectDialog;
