"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { getDownloadLink } from "@/lib/actions";
import {
  Check,
  Copy,
  Download,
  Edit,
  Lock,
  MoreVertical,
  Paperclip,
  PlusCircle,
  Unlock,
  X,
} from "lucide-react";
import { KeyboardEvent, useState } from "react";
import Loader from "./ui/loader";

type CategoryCardProps = {
  category: Category;
  color: string;
  onRemove: () => void;
  onAddItem: () => void;
  onUpdateItem: (itemId: string, updates: Partial<Item | IncomeItem>) => void;
  onRemoveItem: (itemId: string) => void;
  onDuplicateItem: (itemId: string) => void;
  onUpdateCategory: (updates: Partial<Category>) => void;
  allItems: (Item | IncomeItem)[];
  calculateItemAmount: (
    item: Item | IncomeItem,
    allItems: (Item | IncomeItem)[]
  ) => number;
};

export function CategoryCard({
  category,
  color,
  onRemove,
  onAddItem,
  onUpdateItem,
  onRemoveItem,
  onDuplicateItem,
  onUpdateCategory,
  allItems,
  calculateItemAmount,
}: CategoryCardProps) {
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [editedItem, setEditedItem] = useState<Item | IncomeItem | null>(null);
  const [isEditingCategoryName, setIsEditingCategoryName] = useState(false);
  const [editedCategoryName, setEditedCategoryName] = useState(category.name);
  const [preparingDownloadId, setPreparingDownloadId] = useState<string | null>(
    null
  );

  const handleEditItem = (item: Item | IncomeItem) => {
    setEditingItemId(item.id);
    setEditedItem({ ...item, files: [...item.files] });
  };

  const handleSaveItem = () => {
    if (editedItem) {
      onUpdateItem(editedItem.id, editedItem);
      setEditingItemId(null);
      setEditedItem(null);
    }
  };

  const handleCancelEdit = () => {
    setEditingItemId(null);
    setEditedItem(null);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter") {
      handleSaveItem();
    }
  };

  const handleSaveCategoryName = () => {
    onUpdateCategory({ name: editedCategoryName });
    setIsEditingCategoryName(false);
  };

  const calculateCategoryTotal = () => {
    return category.items.reduce(
      (total, item) => total + calculateItemAmount(item, allItems),
      0
    );
  };

  const handleToggleLock = (item: Item | IncomeItem) => {
    onUpdateItem(item.id, { locked: !item.locked });
  };

  const handleToggleCategoryLock = () => {
    onUpdateCategory({ locked: !category.locked });
  };

  const handleFileUpload = (files: FileList) => {
    if (editedItem) {
      const newFiles = Array.from(files).map((file) => ({
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        name: file.name,
        mimetype: file.type,
        file: file,
        thumbnail: URL.createObjectURL(file),
      }));
      setEditedItem({
        ...editedItem,
        files: [...editedItem.files, ...newFiles],
      });
    }
  };

  const handleRemoveFile = (fileId: string) => {
    if (editedItem) {
      setEditedItem({
        ...editedItem,
        files: editedItem.files.filter((file) => file.id !== fileId),
      });
    }
  };

  const handleDownloadFile = async (file: ItemFile) => {
    setPreparingDownloadId(file.id);

    const url = file.thumbnail as string;
    const a = document.createElement("a");
    a.href = url;
    if (file.driveFileId) {
      const downloadLink = await getDownloadLink(file.driveFileId);
      a.href = downloadLink ?? url;
    }
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setPreparingDownloadId(null);
  };

  return (
    <Card className={`mb-4 ${color}`}>
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          {isEditingCategoryName ? (
            <div className="flex items-center space-x-2">
              <Input
                value={editedCategoryName}
                onChange={(e) => setEditedCategoryName(e.target.value)}
                className="font-bold text-lg bg-transparent border-none"
              />
              <Button
                onClick={handleSaveCategoryName}
                size="sm"
                variant="ghost"
              >
                <Check className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <span className="font-bold text-lg">
                {category.name || "Untitled Category"}
              </span>
              <Button
                onClick={() => setIsEditingCategoryName(true)}
                size="sm"
                variant="ghost"
              >
                <Edit className="h-4 w-4" />
              </Button>
            </div>
          )}
          <div className="flex items-center space-x-2">
            {!category.locked && (
              <Button onClick={onRemove} size="sm" variant="ghost">
                <X className="h-4 w-4" />
              </Button>
            )}
            <Button
              onClick={handleToggleCategoryLock}
              size="sm"
              variant="ghost"
            >
              {category.locked ? (
                <Lock className="h-4 w-4" />
              ) : (
                <Unlock className="h-4 w-4" />
              )}
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {category.items.map((item) => (
          <div key={item.id} className="mb-2 p-2 bg-white rounded-md shadow-sm">
            {editingItemId === item.id ? (
              <div className="space-y-2" onKeyDown={handleKeyDown}>
                <div>
                  <Label htmlFor={`item-name-${item.id}`}>Name</Label>
                  <Input
                    id={`item-name-${item.id}`}
                    value={editedItem?.name || ""}
                    onChange={(e) =>
                      setEditedItem({ ...editedItem!, name: e.target.value })
                    }
                    placeholder="Item name"
                  />
                </div>
                {editedItem && "schedule" in editedItem && (
                  <div>
                    <Label htmlFor={`item-schedule-${item.id}`}>Schedule</Label>
                    <Input
                      id={`item-schedule-${item.id}`}
                      value={editedItem.schedule}
                      onChange={(e) =>
                        setEditedItem({
                          ...editedItem,
                          schedule: e.target.value,
                        })
                      }
                      placeholder="Schedule"
                    />
                  </div>
                )}
                {editedItem?.type !== "percentage" && (
                  <div>
                    <Label htmlFor={`item-amount-${item.id}`}>Amount</Label>
                    <Input
                      id={`item-amount-${item.id}`}
                      type="number"
                      value={editedItem?.amount || ""}
                      onChange={(e) =>
                        setEditedItem({
                          ...editedItem!,
                          amount: parseFloat(e.target.value) || 0,
                        })
                      }
                      placeholder="Amount"
                    />
                  </div>
                )}
                <div>
                  <Label htmlFor={`item-type-${item.id}`}>Type</Label>
                  <Select
                    value={editedItem?.type || "fixed"}
                    onValueChange={(value) =>
                      setEditedItem({
                        ...editedItem!,
                        type: value as ItemType,
                      })
                    }
                  >
                    <SelectTrigger id={`item-type-${item.id}`}>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fixed">Fixed</SelectItem>
                      <SelectItem value="percentage">Percentage</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {editedItem?.type === "percentage" && (
                  <>
                    <div>
                      <Label htmlFor={`item-related-${item.id}`}>
                        Related Item
                      </Label>
                      <Select
                        value={editedItem.relatedItemId || ""}
                        onValueChange={(value) =>
                          setEditedItem({
                            ...editedItem,
                            relatedItemId: value,
                          })
                        }
                      >
                        <SelectTrigger id={`item-related-${item.id}`}>
                          <SelectValue placeholder="Select related item" />
                        </SelectTrigger>
                        <SelectContent>
                          {allItems.map((relatedItem) => (
                            <SelectItem
                              key={relatedItem.id}
                              value={relatedItem.id}
                            >
                              {relatedItem.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor={`item-percentage-${item.id}`}>
                        Percentage
                      </Label>
                      <Input
                        id={`item-percentage-${item.id}`}
                        type="number"
                        value={editedItem.percentage || ""}
                        onChange={(e) =>
                          setEditedItem({
                            ...editedItem,
                            percentage: parseFloat(e.target.value) || 0,
                          })
                        }
                        placeholder="Percentage"
                      />
                    </div>
                  </>
                )}
                {editedItem && "schedule" in editedItem && (
                  <>
                    <div>
                      <Label htmlFor={`item-nia-${item.id}`}>NIA</Label>
                      <Input
                        id={`item-nia-${item.id}`}
                        type="number"
                        value={editedItem.nia || ""}
                        onChange={(e) =>
                          setEditedItem({
                            ...editedItem,
                            nia: parseFloat(e.target.value) || 0,
                          })
                        }
                        placeholder="NIA"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`item-pma-${item.id}`}>PM A</Label>
                      <Input
                        id={`item-pma-${item.id}`}
                        type="number"
                        value={editedItem.pmA || ""}
                        onChange={(e) =>
                          setEditedItem({
                            ...editedItem,
                            pmA: parseFloat(e.target.value) || 0,
                            paA: parseFloat(e.target.value) * 12 || 0,
                          })
                        }
                        placeholder="PM A"
                      />
                    </div>
                  </>
                )}
                <div>
                  <Label htmlFor={`item-files-${item.id}`}>Attachments</Label>
                  <Input
                    id={`item-files-${item.id}`}
                    type="file"
                    multiple
                    onChange={(e) => handleFileUpload(e.target.files!)}
                  />
                </div>
                {editedItem?.files && editedItem.files.length > 0 && (
                  <div className="space-y-2">
                    <Label>Attached Files</Label>
                    {editedItem.files.map((file) => (
                      <div
                        key={file.id}
                        className="flex items-center justify-between"
                      >
                        <span>{file.name}</span>
                        <div>
                          <Button
                            onClick={() => handleDownloadFile(file)}
                            size="sm"
                            variant="ghost"
                            disabled={preparingDownloadId === file.id}
                          >
                            {preparingDownloadId === file.id ? (
                              <Loader />
                            ) : (
                              <Download className="h-4 w-4" />
                            )}
                          </Button>
                          <Button
                            onClick={() => handleRemoveFile(file.id)}
                            size="sm"
                            variant="ghost"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                <div className="flex justify-end space-x-2">
                  <Button onClick={handleSaveItem} size="sm">
                    Save
                  </Button>
                  <Button
                    onClick={handleCancelEdit}
                    size="sm"
                    variant="outline"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold">
                      {item.name || "Untitled Item"}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold">
                      ${calculateItemAmount(item, allItems).toFixed(2)}
                    </span>
                    <div className="hidden xl:flex space-x-2">
                      <Button
                        onClick={() => handleEditItem(item)}
                        size="sm"
                        variant="ghost"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      {category.type === "income" && (
                        <Button
                          onClick={() => onDuplicateItem(item.id)}
                          size="sm"
                          variant="ghost"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      )}
                      {item.files && item.files.length > 0 && (
                        <Button size="sm" variant="ghost">
                          <span>
                            <Paperclip className="h-4 w-4" />
                          </span>
                          <span className="ml-1">{item.files.length}</span>
                        </Button>
                      )}
                      {!item.locked && (
                        <Button
                          onClick={() => onRemoveItem(item.id)}
                          size="sm"
                          variant="ghost"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        onClick={() => handleToggleLock(item)}
                        size="sm"
                        variant="ghost"
                      >
                        {item.locked ? (
                          <Lock className="h-4 w-4" />
                        ) : (
                          <Unlock className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                    <div className="xl:hidden">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => handleEditItem(item)}
                          >
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          {category.type === "income" && (
                            <DropdownMenuItem
                              onClick={() => onDuplicateItem(item.id)}
                            >
                              <Copy className="h-4 w-4 mr-2" />
                              Duplicate
                            </DropdownMenuItem>
                          )}
                          {item.files && item.files.length > 0 && (
                            <DropdownMenuItem>
                              <Paperclip className="h-4 w-4 mr-2" />
                              {item.files.length} File(s)
                            </DropdownMenuItem>
                          )}
                          {!item.locked && (
                            <DropdownMenuItem
                              onClick={() => onRemoveItem(item.id)}
                            >
                              <X className="h-4 w-4 mr-2" />
                              Remove
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem
                            onClick={() => handleToggleLock(item)}
                          >
                            {item.locked ? (
                              <>
                                <Lock className="h-4 w-4 mr-2" />
                                Unlock
                              </>
                            ) : (
                              <>
                                <Unlock className="h-4 w-4 mr-2" />
                                Lock
                              </>
                            )}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </div>
                {"schedule" in item && (
                  <div className="text-sm text-gray-600 grid grid-cols-2 gap-2">
                    <div>Schedule: {item.schedule}</div>
                    <div>NIA: {item.nia}</div>
                    <div>PM A: ${item.pmA.toFixed(2)}</div>
                    <div>PA A: ${item.paA.toFixed(2)}</div>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
        <Button onClick={onAddItem} className="w-full mt-2" size="sm">
          <PlusCircle className="h-3.5 w-3.5 mr-2" />
          Add Item
        </Button>
        <div className="font-bold mt-4 text-right">
          Category Total: ${calculateCategoryTotal().toFixed(2)}
        </div>
      </CardContent>
    </Card>
  );
}
