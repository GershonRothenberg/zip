import React, { useState } from "react";
import { PlusCircle, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CategoryCard } from "./category-card";
import { toast } from "@/hooks/use-toast";

type CategorySectionProps = {
  project: Project;
  updateProject: (updates: Partial<Project>) => void;
};

const sectionColors = {
  expense: "bg-red-100 border-red-300",
  income: "bg-green-100 border-green-300",
  capital: "bg-blue-100 border-blue-300",
};

export function CategorySection({
  project,
  updateProject,
}: CategorySectionProps) {
  const [showTotals, setShowTotals] = useState(true);

  const addCategory = (type: "expense" | "income" | "capital") => {
    const newCategory = {
      id: Date.now().toString(),
      name: `New ${type.charAt(0).toUpperCase() + type.slice(1)} Category`,
      type,
      items: [],
      locked: false,
    };
    updateProject({ categories: [...project.categories, newCategory] });
  };

  const removeCategory = (categoryId: string) => {
    const category = project.categories.find((c) => c.id === categoryId);
    if (category && category.locked) {
      toast({
        title: "Error",
        description: "Cannot remove a locked category.",
        variant: "destructive",
      });
      return;
    }
    updateProject({
      categories: project.categories.filter(
        (category) => category.id !== categoryId
      ),
    });
  };

  const updateCategory = (categoryId: string, updates: Partial<Category>) => {
    updateProject({
      categories: project.categories.map((category) =>
        category.id === categoryId ? { ...category, ...updates } : category
      ),
    });
  };

  const addItem = (categoryId: string) => {
    updateProject({
      categories: project.categories.map((category) =>
        category.id === categoryId
          ? {
              ...category,
              items: [
                ...category.items,
                category.type === "income"
                  ? ({
                      id: Date.now().toString(),
                      name: "New Income",
                      amount: 0,
                      type: "fixed",
                      schedule: "",
                      nia: 0,
                      p1: 0,
                      pmA: 0,
                      paA: 0,
                      locked: false,
                      files: [],
                    } as IncomeItem)
                  : ({
                      id: Date.now().toString(),
                      name: "New Item",
                      amount: 0,
                      type: "fixed",
                      locked: false,
                      files: [],
                    } as Item),
              ],
            }
          : category
      ),
    });
  };

  const updateItem = (
    categoryId: string,
    itemId: string,
    updates: Partial<Item | IncomeItem>
  ) => {
    updateProject({
      categories: project.categories.map((category) =>
        category.id === categoryId
          ? {
              ...category,
              items: category.items.map((item) =>
                item.id === itemId ? { ...item, ...updates } : item
              ),
            }
          : category
      ),
    });
  };

  const removeItem = (categoryId: string, itemId: string) => {
    const category = project.categories.find((c) => c.id === categoryId);
    const item = category?.items.find((i) => i.id === itemId);

    if (item && item.locked) {
      toast({
        title: "Error",
        description: "Cannot remove a locked item.",
        variant: "destructive",
      });
      return;
    }

    updateProject({
      categories: project.categories.map((category) =>
        category.id === categoryId
          ? {
              ...category,
              items: category.items.filter((item) => item.id !== itemId),
            }
          : category
      ),
    });
  };

  const duplicateItem = (categoryId: string, itemId: string) => {
    const category = project.categories.find((c) => c.id === categoryId);
    if (!category) return;

    const itemToDuplicate = category.items.find((item) => item.id === itemId);
    if (!itemToDuplicate) return;

    const newItem = {
      ...itemToDuplicate,
      id: Date.now().toString(),
      name: `${itemToDuplicate.name} (Copy)`,
      locked: false,
    };

    updateProject({
      categories: project.categories.map((c) =>
        c.id === categoryId ? { ...c, items: [...c.items, newItem] } : c
      ),
    });
  };

  const calculateItemAmount = (
    item: Item | IncomeItem,
    allItems: (Item | IncomeItem)[]
  ): number => {
    if (item.type === "fixed") {
      return item.amount;
    } else if (
      item.type === "percentage" &&
      item.relatedItemId &&
      item.percentage
    ) {
      const relatedItem = allItems.find((i) => i.id === item.relatedItemId);

      if (relatedItem?.type === "percentage") {
        return (
          (calculateItemAmount(relatedItem, allItems) * item.percentage) / 100
        );
      }

      return relatedItem ? (relatedItem.amount * item.percentage) / 100 : 0;
    }

    return 0;
  };

  const calculateTotal = (type: "expense" | "income" | "capital") => {
    let total = 0;

    // Calculate total from categories
    const allItems = project.categories.flatMap((c) => c.items);

    total += project.categories
      .filter((category) => category.type === type)
      .reduce((categoryTotal, category) => {
        return (
          categoryTotal +
          category.items.reduce((sum, item) => {
            return sum + calculateItemAmount(item, allItems);
          }, 0)
        );
      }, 0);

    console.log("total: ", type, total);

    // Add capital investments to the total if the type is 'capital'
    if (type === "capital" || type === "expense") {
      total += project.capitalInvestments.reduce(
        (sum, investment) => sum + investment.amount,
        0
      );
    }

    return total;
  };

  const calculateIncomeTotals = () => {
    const incomeCategory = project.categories.find(
      (category) => category.type === "income"
    );
    if (!incomeCategory)
      return { niaTotal: 0, p1Total: 0, pmATotal: 0, paATotal: 0 };

    return (incomeCategory.items as IncomeItem[]).reduce(
      (totals, item) => {
        totals.niaTotal += item.nia || 0;
        totals.pmATotal += item.pmA || 0;
        totals.paATotal += item.paA || 0;
        return totals;
      },
      { niaTotal: 0, p1Total: 0, pmATotal: 0, paATotal: 0 }
    );
  };

  const { niaTotal, pmATotal, paATotal } = calculateIncomeTotals();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {["expense", "income", "capital"].map((type) => (
        <div key={type}>
          <h2 className="text-2xl font-bold mb-4">
            {type.charAt(0).toUpperCase() + type.slice(1)}s
          </h2>
          {project.categories
            .filter((category) => category.type === type)
            .map((category) => (
              <CategoryCard
                key={category.id}
                category={category}
                color={
                  sectionColors[category.type as keyof typeof sectionColors]
                }
                onRemove={() => removeCategory(category.id)}
                onAddItem={() => addItem(category.id)}
                onUpdateItem={(itemId, updates) =>
                  updateItem(category.id, itemId, updates)
                }
                onRemoveItem={(itemId) => removeItem(category.id, itemId)}
                onDuplicateItem={(itemId) => duplicateItem(category.id, itemId)}
                onUpdateCategory={(updates) =>
                  updateCategory(category.id, updates)
                }
                allItems={project.categories.flatMap((c) => c.items)}
                calculateItemAmount={calculateItemAmount}
              />
            ))}
          <Button
            onClick={() =>
              addCategory(type as "expense" | "income" | "capital")
            }
            className="w-full mt-4"
          >
            <PlusCircle className="h-4 w-4 mr-2" /> Add{" "}
            {type.charAt(0).toUpperCase() + type.slice(1)} Category
          </Button>

          {type === "income" && (
            <Card className={`mt-4 ${sectionColors["income"]}`}>
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-lg font-semibold">Income Totals</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowTotals(!showTotals)}
                  >
                    {showTotals ? (
                      <ChevronUp className="h-4 w-4" />
                    ) : (
                      <ChevronDown className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                {showTotals && (
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>NIA:</span>
                      <span className="font-semibold">{niaTotal}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>P1:</span>
                      <span className="font-semibold">
                        ${paATotal.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>PM A:</span>
                      <span className="font-semibold">
                        ${pmATotal.toFixed(2)}
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          <Card
            className={`mt-4 ${
              sectionColors[type as keyof typeof sectionColors]
            }`}
          >
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold mb-2">
                {type.charAt(0).toUpperCase() + type.slice(1)} Total
              </h3>
              <div className="text-2xl font-bold">
                $
                {calculateTotal(
                  type as "expense" | "income" | "capital"
                ).toFixed(2)}
              </div>
            </CardContent>
          </Card>
        </div>
      ))}
    </div>
  );
}
