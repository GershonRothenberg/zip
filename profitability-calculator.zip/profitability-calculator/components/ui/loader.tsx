import { cn } from "@/lib/utils";
import { LoaderIcon } from "lucide-react";
import React from "react";

const Loader = ({ className }: { className?: string }) => {
  return <LoaderIcon className={cn("w-4 h-4 animate-spin", className)} />;
};

export default Loader;
